#include "Common.h"
#include "ControlWindow.h"
#include "Server.h"

#include "_version.h"

int CALLBACK WinMain(HINSTANCE hInstance,
   HINSTANCE hPrevInstance,
   LPSTR lpCmdLine,
   int nCmdShow)
{
   AllocConsole();

   freopen("CONIN$", "r", stdin); 
   freopen("CONOUT$", "w", stdout); 
   freopen("CONOUT$", "w", stderr); 

   SetConsoleTitle(TEXT("Hidden Desktop"));
  
   wprintf(TEXT("Version: %S\n"), VERSION_STRING);
   wprintf(TEXT("Compiled: %S @ %S\n"), __DATE__, __TIME__);

   if(!StartServer(10000))
   {
      wprintf(TEXT("Could not start the server (Error: %d)\n"), WSAGetLastError()); 
      getchar();
      return 0;
   }
   return 0;
}